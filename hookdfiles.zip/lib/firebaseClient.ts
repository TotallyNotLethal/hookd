import { initializeApp, getApps, getApp, FirebaseApp } from "firebase/app";
import { getAuth, GoogleAuthProvider } from "firebase/auth";
import { getFirestore } from "firebase/firestore";
import { getStorage, FirebaseStorage } from "firebase/storage";

const firebaseConfig = {
  apiKey: "AIzaSyDmF3UWRSfMILLTMmzU1_PishWAZNlphtk",
  authDomain: "hookd-b7ae6.firebaseapp.com",
  projectId: "hookd-b7ae6",
  storageBucket: "hookd-b7ae6.firebasestorage.app",
  messagingSenderId: "627079728513",
  appId: "1:627079728513:web:285951645efe65a065ac80",
  measurementId: "G-ZRHCCWK1BQ",
};

// --- create or reuse the single app instance
let app: FirebaseApp;
if (!getApps().length) app = initializeApp(firebaseConfig);
else app = getApp();

// --- force-bind the bucket name manually
let storage: FirebaseStorage;
try {
  storage = getStorage(app, "gs://hookd-b7ae6.firebasestorage.app");
} catch (err) {
  console.error("Storage init failed:", err);
  storage = getStorage(app);
}

const auth = getAuth(app);
const googleProvider = new GoogleAuthProvider();
const db = getFirestore(app);

console.log("✅ Firebase initialized with bucket:", storage.bucket);

export { app, auth, googleProvider, db, storage };
