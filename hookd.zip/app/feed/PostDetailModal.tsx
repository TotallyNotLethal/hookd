'use client';
import { useEffect, useState } from 'react';
import { addComment, subscribeToComments, subscribeToUserLike, toggleLike } from '@/lib/firestore';
import { getAuth } from 'firebase/auth';
import { app } from '@/lib/firebaseClient';
import { Heart } from 'lucide-react';

export default function PostDetailModal({ post, onClose }: { post:any; onClose:()=>void }) {
  const auth = getAuth(app);
  const user = auth.currentUser;
  const [comments, setComments] = useState<any[]>([]);
  const [text, setText] = useState('');
  const [liked, setLiked] = useState(false);

  useEffect(() => {
    if (!user) return;
    const unsub = subscribeToUserLike(post.id, user.uid, setLiked);
    const unsubC = subscribeToComments(post.id, setComments);
    return () => { unsub(); unsubC(); };
  }, [post.id, user?.uid]);

  async function sendComment() {
    if (!user || !text.trim()) return;
    await addComment(post.id, { uid: user.uid, displayName: user.displayName || 'Angler', photoURL: user.photoURL || undefined, text });
    setText('');
  }

  return (
    <div className="fixed inset-0 bg-black/60 z-50 flex items-center justify-center">
      <div className="bg-[var(--card)] border border-white/10 rounded-2xl w-full max-w-3xl overflow-hidden">
        <div className="grid grid-cols-1 md:grid-cols-2">
          <div className="relative md:min-h-[480px]">
            {post.imageUrl && <img src={post.imageUrl} alt={post.species} className="w-full h-full object-cover" />}
          </div>
          <div className="p-4 space-y-3">
            <div className="flex items-center justify-between">
              <h3 className="font-semibold">{post.species}</h3>
              <button onClick={onClose} className="opacity-70 hover:opacity-100">✕</button>
            </div>

            <div className="flex items-center gap-2">
              <button onClick={() => user && toggleLike(post.id, user.uid)} className={`flex items-center gap-1 ${liked ? 'text-red-500' : 'opacity-60 hover:opacity-100'}`}>
                <Heart className={`w-5 h-5 ${liked ? 'fill-red-500 stroke-red-500' : ''}`} />
              </button>
              <span className="opacity-60 text-sm">{post.commentsCount || 0} comments</span>
            </div>

            <div className="space-y-2 max-h-64 overflow-y-auto pr-2">
              {comments.map((c) => (
                <div key={c.id} className="text-sm"><span className="font-medium">{c.displayName}</span> {c.text}</div>
              ))}
              {comments.length === 0 && <p className="opacity-60 text-sm">No comments yet.</p>}
            </div>

            <div className="flex gap-2">
              <input className="input flex-1" placeholder="Write a comment…" value={text} onChange={e=>setText(e.target.value)} onKeyDown={(e)=>{ if(e.key==='Enter') sendComment(); }} />
              <button className="btn-primary" onClick={sendComment}>Send</button>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
